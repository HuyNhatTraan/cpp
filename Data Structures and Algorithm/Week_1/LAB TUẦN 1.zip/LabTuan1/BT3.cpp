// Ho va ten: Tran Nhat Huy
// MSSV: 221A010568

#include <bits/stdc++.h>
using namespace std;

/* 1.3.1. Thông tin của một môn học gồm có: mã môn học (kiểu chuỗi 10 kí tự), tên
môn học (kiểu chuỗi 30 kí tự), số tín chỉ (kiểu số nguyên).
Hãy viết chương trình thực hiện các yêu cầu sau:
    - Nhập một danh sách các môn học (tối đa 20 môn học)
    - Xuất danh sách môn học đã nhập ra màn hình.
    - Xuất ra màn hình danh sách các môn học có số tín chỉ >2.
    - Tính tổng số tín chỉ của các môn học có trong danh sách.
    - Tìm kiếm một môn học khi biết mã số môn học, cho biết môn học này có tồn
    tại hay không? */

class QuanLyMonHoc{
private:
    vector<string> MaMonHoc;
    vector<string> TenMonHoc;
    vector<int> TinChi;
public: 
    void nhapThongTin(){
        string id, name;
        int tinchi;
        cout << "Hãy nhập mã môn học: ";
        cin.ignore();
        getline(cin, id);
        if (id.length() > 10){
            cout << "Mã môn học vượt quá độ dài cho phép (dưới 10). Vui lòng nhập lại! \n";
            cout << "Hãy nhập lại mã môn học: ";
            getline(cin, id);
        }
        MaMonHoc.push_back(id);
        cout << "Hãy nhập tên môn học: ";
        getline(cin, name);
        if (name.length() > 10){
            cout << "Tên môn học vượt quá độ dài cho phép (dưới 30). Vui lòng nhập lại! \n";
            cout << "Hãy nhập lại tên môn học: ";
            getline(cin, name);
        }
        TenMonHoc.push_back(name);
        cout << "Hãy nhập số tín chỉ của môn học này: ";
        cin >> tinchi;
        TinChi.push_back(tinchi);
        cout << "Da luu thanh cong! \n";
    }
    void xuatThongTin(){
        for (int i = 0; i < TinChi.size(); i++){
            cout << "====================================== \n";
            cout << "- Tên môn học: " << TenMonHoc[i] << endl;
            cout << "- Mã môn: " << MaMonHoc[i] << endl;
            cout << "- Số tín chỉ của môn học này: " << TinChi[i] << endl;
            cout << "====================================== \n";
        }
    }
    void tren2TinChi(){
        int dem = 1;
        for (int i = 0; i < TinChi.size(); i++) {
            if (TinChi[i] > 2) {
                cout << "====================================== \n";
                cout << "Những môn học trên 2 tín chỉ: " << endl;
                cout << dem++ << ". "<< TenMonHoc[i] << " " << MaMonHoc[i] << endl;
                cout << "====================================== \n";
            } else {
                cout << "Không tìm thấy những môn trên 2 tín chỉ \n";
            }
        }
    }
    void tinhTongTinChi(){
        int tong = 0;
        for (int i = 0; i < TinChi.size(); i++) {
            tong += TinChi[i];
        }
        cout << "Tổng số tín chỉ của bạn là: " << tong << endl;
    }
    void timKiemMonHoc(){
        string id;
        cout << "Hãy nhập mã số môn học mà bạn muốn tìm kiếm: ";
        cin >> id;
        for (int i = 0; i < TinChi.size(); i++) {
            if (id == MaMonHoc[i]) {
                cout << "Đã tìm thấy môn học này! \n";
                cout << "====================================== \n";
                cout << "- Tên môn học: " << TenMonHoc[i] << endl;
                cout << "- Mã môn: " << MaMonHoc[i] << endl;
                cout << "- Số tín chỉ của môn học này: " << TinChi[i] << endl;
                cout << "====================================== \n";
                break;
            } else {
                cout << "Không tìm thấy thông tin của môn học này! \n";
            }
        }
    }
};

void menu(){
    cout << "================ Menu ================ \n";
    cout << "1. Nhập thông tin môn học." << endl;
    cout << "2. Xuất các thông tin môn học." << endl;
    cout << "3. Xuất các thông tin môn học trên 2 tín chỉ." << endl;
    cout << "4. Tính tổng số tín chỉ mà bạn đã nhập." << endl;
    cout << "5. Tìm kiếm thông tin môn học." << endl;
    cout << "6. Thoát khỏi menu." << endl;
    cout << "====================================== \n";
    cout << "Hãy nhập lựa chọn của bạn: ";
}

int main(){
    QuanLyMonHoc QLMH;
    int choices;
    do {
        menu();
        cin >> choices;
        switch (choices)
        {
        case 1:
            QLMH.nhapThongTin();
            break;
        case 2:
            QLMH.xuatThongTin();
            break;
        case 3:
            QLMH.tren2TinChi();
            break;
        case 4:
            QLMH.tinhTongTinChi();
            break;
        case 5:
            QLMH.timKiemMonHoc();
            break;
        case 6:
            cout << "Thoát khỏi Menu!. " << endl;
            return 0;
        default:
            cout << "Bạn nhập sai rồi vui lòng nhập lại!." << endl;
            break;
        }
    } while (choices != 6);
    return 0;
}
