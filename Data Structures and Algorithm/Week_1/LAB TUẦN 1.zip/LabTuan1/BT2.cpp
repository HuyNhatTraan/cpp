// Ho va ten: Tran Nhat Huy
// MSSV: 221A010568

#include <bits/stdc++.h>
using namespace std;

struct PhanSo {
    int tuSo;
    int mauSo;
};

PhanSo nhapPhanSo() {
    PhanSo ps;
    cout << "Nhap tu so: ";
    cin >> ps.tuSo;
    cout << "Nhap mau so: ";
    cin >> ps.mauSo;
    return ps;
}

PhanSo congPhanSo(PhanSo ps1, PhanSo ps2) {
    PhanSo ketQua;
    ketQua.tuSo = ps1.tuSo * ps2.mauSo + ps2.tuSo * ps1.mauSo;
    ketQua.mauSo = ps1.mauSo * ps2.mauSo;
    return ketQua;
}

PhanSo nhanPhanSo(PhanSo ps1, PhanSo ps2) {
    PhanSo ketQua;
    ketQua.tuSo = ps1.tuSo * ps2.tuSo;
    ketQua.mauSo = ps1.mauSo * ps2.mauSo;
    return ketQua;
}

PhanSo chiaPhanSo(PhanSo ps1, PhanSo ps2) {
    PhanSo ketQua;
    ketQua.tuSo = ps1.tuSo * ps2.mauSo;
    ketQua.mauSo = ps1.mauSo * ps2.tuSo;
    return ketQua;
}

void inPhanSo(PhanSo ps) {
    cout << ps.tuSo << "/" << ps.mauSo << endl;
}

int main() {
    PhanSo ps1 = nhapPhanSo();
    PhanSo ps2 = nhapPhanSo();
    PhanSo tong = congPhanSo(ps1, ps2);
    PhanSo tich = nhanPhanSo(ps1, ps2);
    PhanSo chia = chiaPhanSo(ps1, ps2);
    cout << "Tổng 2 phân số là: ";
    inPhanSo(tong);
    cout << "Tích 2 phân số là: ";
    inPhanSo(tich);
    cout << "Chia 2 phân số là: ";
    inPhanSo(chia);
    return 0;
}
