// Ho va ten: Tran Nhat Huy
// MSSV: 221A010568

#include <bits/stdc++.h>
using namespace std;

//  Mã sách char[10], tên sách [40] và giá
//  Chức năng : nhập, xuất, tìm kiếm bằng = pp tuần tự, tìm kiếm bằng = pp nhị phân, 
//  liệt kê các món có giá > G (G nhập từ người dùng) và tìm cuốn sách có giá lớn nhất

class QuanLySach{
private:
    vector<string> MaSach;
    vector<string> TenSach;
    vector<long> Gia;
public:
    void nhapThongTin(){
        string id, ten;
        long gia;
        cout << "Nhập thông tin sách: \n";
        cout << "Hãy nhập mã sách: ";
        cin.ignore();
        getline(cin, id);
        if (id.length() > 10){
            cout << "Mã sách vượt quá độ dài cho phép (dưới 10 ký tự). Vui lòng nhập lại! \n";
            return;
        }
        MaSach.push_back(id);
        cout << "Hãy nhập tên sách: ";
        getline(cin, ten);
        if (ten.length() > 40){
            cout << "Mã sách vượt quá độ dài cho phép (dưới 40 ký tự). Vui lòng nhập lại! \n";
            return;
        }
        TenSach.push_back(ten);
        cout << "Hãy nhập đơn giá sách: ";
        cin >> gia;
        Gia.push_back(gia);
    }

    void xuatThongTin(){
        for (int i = 0; i < Gia.size(); i++) {
            cout << "====================================================================== \n";
            cout << "Tên sách: " << TenSach[i] << endl;
            cout << "Mã sách: " << MaSach[i] << endl;
            cout << "Giá sách: " << Gia[i] << " VND" << endl;
            cout << "====================================================================== \n";
        }
    }

    void timKiemTuanTu(){
        string x; // x = ma
        cout << "Hãy nhập mã sách bạn muốn tìm kiếm: "; 
        cin >> x;
        for (int i = 0; i < Gia.size(); i++){
            if (MaSach[i] == x) {
                cout << "Đã tìm thấy sách mà bạn muốn tìm! \n";
                cout << "====================================================================== \n";
                cout << "Tên sách: " << TenSach[i] << endl;
                cout << "Mã sách: " << MaSach[i] << endl;
                cout << "Giá sách: " << Gia[i] << " VND" << endl;
                cout << "====================================================================== \n";
            } else 
                cout << "Không tìm thấy mã sách này! \n";
        }
    }

    void timKiemNhiPhan(){
        string x; // x = ma
        cout << "Hãy nhập mã sách bạn muốn tìm kiếm: "; 
        cin >> x;
        // Sắp xếp lại mã sách
        sort(MaSach.begin(), MaSach.end());
        int left = 0, right = Gia.size() - 1, mid;
        bool timThay = false;

        for (int i = left; i < right; i++){
            mid = (left + right) / 2;
            if (MaSach[mid] == x ) { /* x = mã */
                cout << "Đã tìm thấy sách \n";
                timThay == true;
                cout << "====================================================================== \n";
                cout << "Tên sách: " << TenSach[i] << endl;
                cout << "Mã sách: " << MaSach[i] << endl;
                cout << "Giá sách: " << Gia[i] << " VND" << endl;
                cout << "====================================================================== \n";
            } else if (MaSach[mid] < x) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        if (timThay = false){
            cout << "Không tìm thấy mã sách này! \n";
        }
        
    }

    // Liệt kê các sách có giá > G (G nhập từ người dùng)
    void lietKe(){
        long price;
        int dem = 0;
        cout << "Hãy nhập giá tiền bạn muốn xem những sách cao hơn số tiền bạn có: ";
        cin >> price;
        for (int i = 0; i < Gia.size(); i++){
            if(Gia[i] > price){
                cout << "====================================================================== \n";
                cout << "Những sách có giá cao hơn là: " << endl;
                cout << dem++ << ". " << TenSach[i] << " với giá " << Gia[i] << " VND" << endl;
                cout << "====================================================================== \n";
            } else 
                cout << "Không có sách nào thấp hơn giá tiền của bạn! \n";
        }
    }

    // Tìm cuốn sách có giá lớn nhất
    void sachDatNhat(){
        long maxprice = 0;
        for (int i = 0; i < Gia.size(); i++){
            if (maxprice < Gia[i]){
                maxprice = Gia[i];
            }
        }
        cout << "Giá quyển sách cao nhất là: " << maxprice << endl;
    }
};

void menu(){
    cout << "================================ Menu ================================ \n";
    cout << "1. Nhập thông tin cho sách." << endl;
    cout << "2. Hiển thông tin sách." << endl;
    cout << "3. Tìm thông tin sách bằng pp tìm kiếm tuần tự." << endl;
    cout << "4. Tìm thông tin sách bằng pp tìm kiếm nhị phân." << endl;
    cout << "5. Liệt kê những loại sách có giá lớn hơn giá nhập từ người dùng." << endl;
    cout << "6. Tìm cuốn sách có giá cao nhất. " << endl;
    cout << "7. Thoát khỏi menu!." << endl;
    cout << "=============================== [01] ================================== \n";
    cout << "Hãy nhập lựa chọn của bạn: ";
}

int main(){
    QuanLySach QLS;
    int choices;
    do {
        menu();
        cin >> choices;
        switch (choices) {
            case 1:
                QLS.nhapThongTin();
                break;
            case 2:
                QLS.xuatThongTin();
                break;
            case 3:
                QLS.timKiemTuanTu();
                break;
            case 4:
                QLS.timKiemNhiPhan();
                break;
            case 5:
                QLS.lietKe();
                break;
            case 6:
                QLS.sachDatNhat();
                break;
            case 7:
                cout << "Thoát khỏi menu. \n";
                break;     
            default:
                break;
        }
    } while (choices != 7);
    return 0;
}
