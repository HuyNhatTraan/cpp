// Ho va ten: Tran Nhat Huy
// MSSV: 221A010568

#include <bits/stdc++.h>
using namespace std;

/* 1.4.1. Thông tin của một Phòng ban gồm có: mã phòng ban, tên phòng ban,
trưởng phòng. Biết rằng trưởng phòng là một nhân viên có các thông tin sau:
mã nhân viên, tên nhân viên, ngày sinh (ngày, tháng, năm), ngày vào làm (ngày,
tháng, năm). Hãy viết chương trình thực hiện các yêu cầu sau:
    - Nhập danh sách các phòng ban (tối đa 20 phòng)
    - Xuất danh sách đã nhập
    - In ra thông tin trưởng phòng khi biết mã số phòng ban.
    - In ra thông tin các trưởng phòng có ngày sinh vào tháng 10.
    - In ra thông tin phòng ban khi biết mã số trưởng phòng. */

class QuanLyPhongBan{
private:
    vector <string> MaPhongBan;
    vector <string> TenPhongBan;
    vector <string> TenNhanVien;
    vector <string> MaNhanVien;
    vector <int> NgaySinh, ThangSinh, NamSinh;
    vector <int> NgayVaoLam, ThangVaoLam, NamVaoLam;
public:
    void nhapThongTin(){
        string id, tenphong, name, idnv;
        int day, month, year, dayin, monthin, yearin;
        cout << "Hãy nhập thông tin phòng (tối đa 20): \n";
        for (int i = 0; i < 20; i++) {
            if (i < 20) {
                cout << "Phòng ban " << i + 1 << ": " << endl;
                // Thông ctin phòng ban
                cout << "Hãy nhập mã phòng ban: ";
                cin.ignore();
                getline(cin, id);
                MaPhongBan.push_back(id);
                cout << "Hãy nhập tên phòng ban: ";
                getline(cin, tenphong);
                TenPhongBan.push_back(tenphong);
                cout << "Hãy nhập tên nhân viên: ";
                getline(cin, name);
                TenNhanVien.push_back(name);
                cout << "Hãy nhập mã nhân viên: ";
                getline(cin, idnv);
                MaNhanVien.push_back(idnv);
                // Ngày tháng năm sinh
                cout << "Hãy nhập ngày sinh: "; cin >> day;
                NgaySinh.push_back(day);
                cout << "Hãy nhập tháng sinh: "; cin >> month;
                ThangSinh.push_back(month);
                cout << "Hãy nhập năm sinh: "; cin >> year;
                NamSinh.push_back(year);
                // Ngày vào làm
                cout << "Hãy nhập ngày vào làm: "; cin >> dayin;
                NgayVaoLam.push_back(dayin);
                cout << "Hãy nhập tháng vào làm: "; cin >> monthin;
                ThangVaoLam.push_back(monthin);
                cout << "Hãy nhập năm vào làm: "; cin >> yearin;
                NamVaoLam.push_back(yearin);
                break;
            } else {
                cout << "Đã vượt quá 20 phòng! Hãy xoá bớt nếu muốn thêm vào! \n";
            }
        }
        }
    void xuatDanhSach(){
        for (int i = 0; i < MaPhongBan.size(); i++){
            cout << "====================================== \n";
            cout << "Phòng ban " << i + 1 << ": " << endl;
            cout << "Mã phòng ban: " << MaPhongBan[i] << endl;
            cout << "Tên phòng ban: " << TenPhongBan[i] << endl;
            cout << "Tên nhân viên: " << TenNhanVien[i] << endl;
            cout << "Mã số nhân viên: " << MaNhanVien[i] << endl;
            cout << "Ngày tháng năm sinh: " << NgaySinh[i] << "/" << ThangSinh[i] << "/" << NamSinh[i] << endl;
            cout << "Ngày vào làm: " << NgayVaoLam[i] << "/" << ThangVaoLam[i] << "/" << NamVaoLam[i] << endl; 
            cout << "====================================== \n";
        }
    }
    // In ra thông tin trưởng phòng khi biết mã số phòng ban
    void timKiemTruongPhongBan(){
        string id;
        cout << "Hãy nhập mã phòng ban: ";
        cin >> id;
        for (int i = 0; i < MaPhongBan.size(); i++){
            if (id == MaPhongBan[i]) {
                cout << "Đã tìm thấy thông tin! \n";
                cout << "====================================== \n";
                cout << "Tên nhân viên: " << TenNhanVien[i] << endl;
                cout << "Mã số nhân viên: " << MaNhanVien[i] << endl;
                cout << "Ngày tháng năm sinh: " << NgaySinh[i] << "/" << ThangSinh[i] << "/" << NamSinh[i] << endl;
                cout << "Ngày vào làm: " << NgayVaoLam[i] << "/" << ThangVaoLam[i] << "/" << NamVaoLam[i] << endl; 
                cout << "====================================== \n";
            } else 
                cout << "Không tìm thấy nhân viên này." << endl;
        }
    }
    // In thông tin trưởng phòng ban có ngày sinh vào tháng 10.
    void inThongTinTTThang10(){
        for (int i = 0; i < MaPhongBan.size(); i++){
            if (NgaySinh[i] == 10) {
                cout << "Đã tìm thấy thông tin! \n";
                cout << "====================================== \n";
                cout << "Tên nhân viên: " << TenNhanVien[i] << endl;
                cout << "Mã số nhân viên: " << MaNhanVien[i] << endl;
                cout << "Ngày tháng năm sinh: " << NgaySinh[i] << "/" << ThangSinh[i] << "/" << NamSinh[i] << endl;
                cout << "Ngày vào làm: " << NgayVaoLam[i] << "/" << ThangVaoLam[i] << "/" << NamVaoLam[i] << endl; 
                cout << "====================================== \n";
            } else 
                cout << "Không tìm thấy nhân viên này." << endl;
        }
    }
    // In thông phòng ban khi biết mã trưởng phòng.
    void xuatThongTinPhongBan(){
        string id;
        cout << "Hãy nhập mã trưởng phòng: ";
        cin.ignore();
        getline(cin, id);
        for (int i = 0; i < MaPhongBan.size(); i++){
            if (MaNhanVien[i] == id) {
                cout << "Đã tìm thấy thông tin! \n";
                cout << "====================================== \n";
                cout << "Mã phòng ban: " << MaPhongBan[i] << endl;
                cout << "Tên phòng ban: " << TenPhongBan[i] << endl;
                cout << "Tên nhân viên: " << TenNhanVien[i] << endl;
                cout << "Mã số nhân viên: " << MaNhanVien[i] << endl;
                cout << "Ngày tháng năm sinh: " << NgaySinh[i] << "/" << ThangSinh[i] << "/" << NamSinh[i] << endl;
                cout << "Ngày vào làm: " << NgayVaoLam[i] << "/" << ThangVaoLam[i] << "/" << NamVaoLam[i] << endl; 
                cout << "====================================== \n";
            } else 
                cout << "Không tìm thấy nhân viên này." << endl;
        }
    }
};

void menu(){
    cout << "================ Menu ================ \n";
    cout << "1. Nhập danh sách phòng ban." << endl;
    cout << "2. Xuất danh sách phòng ban." << endl;
    cout << "3. In ra thông tin trưởng phòng khi biết mã số phòng ban." << endl;
    cout << "4. In thông tin trưởng phòng ban có ngày sinh vào tháng 10." << endl;
    cout << "5. In thông phòng ban khi biết mã trưởng phòng." << endl;
    cout << "6. Thoát khỏi menu!." << endl;
    cout << "================ [01] ================= \n";
    cout << "Hãy nhập lựa chọn của bạn: ";
}

int main(){
    QuanLyPhongBan QLPB;
    int choices;
    do {
        menu();
        cin >> choices;
        switch (choices){
            case 1:
                QLPB.nhapThongTin();
                break;
            case 2:
                QLPB.xuatDanhSach();
                break;
            case 3:
                QLPB.timKiemTruongPhongBan();
                break;
            case 4:
                QLPB.inThongTinTTThang10();
                break;
            case 5:
                QLPB.xuatThongTinPhongBan();
                break;
            case 6:
                cout << "Thoát khỏi menu!. \n";
                break;
            default:
                cout << "Bạn nhập sai rồi vui lòng nhập lại! \n";
                break;
        }
    } while (choices != 6);
    return 0;
}
