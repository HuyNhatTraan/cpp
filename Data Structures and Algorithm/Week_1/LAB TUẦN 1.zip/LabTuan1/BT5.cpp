// Ho va ten: Tran Nhat Huy
// MSSV: 221A010568

#include <bits/stdc++.h>
using namespace std;

/* Sinh mảng ngẫu nhiên (-100 -> 100) cho số mảng = 8
     - Tìm phần tử có giá trị X trong mảng bằng 2 phương pháp tìm tuần tự và tìm nhị phân.
*/ 

void randomXD(int arr[8], int n){
    // Cho số mảng là 8
    srand(time(NULL)); 
    cout << "Số ngẫu nhiên là: \n";
    for (int i = 0; i < 8; i++){
        arr[i] = rand() % (100 - (-100) + 1) + -100;
        cout << arr[i] << " ";
    }
    cout << endl;
}
void timTuanTu(int arr[8], int x){
    cout << "Hãy nhập số mà bạn muốn tìm (tuần tự): ";
    cin >> x;
    bool timThay = false;
    for (int i = 0; i < 8; i++){
        if (arr[i] == x){
            timThay = true;
            cout << "Đã tìm thấy số bạn cần tìm: " << x << endl;
            break;
        }
    }
    if(!timThay){
        cout << "Không tìm thấy số bạn cần tìm \n";
    }
}
void timNhiPhan(int arr[8], int x){
    cout << "Hãy nhập số bạn cần tìm (nhị phân): "; cin >> x;
    int left = 0, right = 8 - 1, mid;
    bool timThay = false;
    sort(arr, arr + 8);
    for (int i = 0; i < right; i++){
        mid = (left + right) / 2;
        if (arr[mid] == x){
            timThay = true;
            cout << "Đã tìm thấy dữ liệu " << x << endl;
            break;
        } else if (arr[mid] < x){
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }
    if (!timThay){
        cout << "Không tìm thấy số này! \n";
    }
}

int main(){
    int n, x, arr[8];
    randomXD(arr, n);
    timTuanTu(arr, x);
    timNhiPhan(arr, x);
    return 0;
}
