// Ho va ten: Tran Nhat Huy
// MSSV: 221A010568

#include <bits/stdc++.h>
using namespace std;
// Nhập xuất ma trận / mảng 2 chiều
const int MAXDONG = 100;
const int MAXCOT = 100;

void nhapMaTran2D(int arr[][MAXCOT], int &d, int &c){ // d = dòng / c = cột
    cout << "Hãy nhập số dòng bạn muốn có trong ma trận: "; cin >> d;
    cout << "Hãy nhập số cột bạn muốn có trong ma trận: "; cin >> c;
    for (int i = 0; i < d; i++){
        for (int j = 0; j < d; j++){
            cout << "Hãy nhập phần tử [" << i << "][" << j << "]: ";
            cin >> arr[i][j];
        }
    }
}

void xuatMaTran2D(int arr[][MAXCOT], int d, int c){ // d = dòng / c = cột
    cout << "Ma trận " << d << " x " << c << " bạn đã nhập là: " << endl; 
    for (int i = 0; i < d; i++){
        for (int j = 0; j < d; j++){
            cout << arr[i][j] << " ";
        }
        cout << "\n";
    }
}

int main(){
    int arr[MAXDONG][MAXCOT], d, c;
    nhapMaTran2D(arr, d, c);
    xuatMaTran2D(arr, d, c);
    return 0;
}
